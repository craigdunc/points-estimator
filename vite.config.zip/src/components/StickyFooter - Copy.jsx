import React from 'react'

export default function StickyFooter({
  totalPts,
  rewardTabs,
  activeRewardTab,
  availableRewards,
  selectedRewardId,
  onRewardTabChange,
  onRewardSelect,
  onAddToDashboard
}) {
  return (
    <div className="fixed bottom-0 inset-x-0 bg-white border-t shadow-lg p-4">
      {/* Points and Reward Tabs */}
      <div className="flex items-center justify-between mb-3">
        <div className="font-semibold">Est {totalPts.toLocaleString()} PTS/yr</div>
        <div className="flex space-x-4 overflow-x-auto">
          {rewardTabs.map(tab => (
            <button
              key={tab}
              onClick={() => onRewardTabChange(tab)}
              className={`text-sm whitespace-nowrap ${activeRewardTab === tab ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-600'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Rewards List */}
      <div className="flex space-x-3 overflow-x-auto pb-3">
        {availableRewards.map(r => (
          <button
            key={r.id}
            onClick={() => onRewardSelect(r.id)}
            className={`min-w-[180px] border rounded p-2 text-left ${selectedRewardId === r.id ? 'border-2 border-red-600' : ''}`}
          >
            <div className="font-medium text-sm mb-1">{r.reward}</div>
            <div className="text-xs text-gray-600">
              {r.costAUD ? `Use ${r.pts.toLocaleString()} PTS + $${r.costAUD.toFixed(2)}` : `${r.pts.toLocaleString()} PTS`}
            </div>
          </button>
        ))}
      </div>

      {/* Add to Dashboard Button */}
      <button onClick={onAddToDashboard} className="w-full py-2 bg-red-600 text-white rounded">
        Add to Dashboard
      </button>
    </div>
  )
}
