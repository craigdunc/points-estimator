import React, { useState, useEffect } from 'react';
import PointsRooLogo from '../assets/points-roo.svg';
import CategoryTabs from './CategoryTabs';

const rewardLabels = {
    Flights:        'Reward Flights',
    Hotels:         'Qantas Hotels',
    Activities:     'Qantas Activities',
    Marketplace:    'Qantas Marketplace',
    'Gift Cards':   'Gift Cards',
    Entertainment: 'Entertainment'
};

export default function StickyFooter({
    totalPts,
    rewardTabs,
    activeRewardTab,
    availableRewards,
    selectedRewardId,
    onSelectReward,
    onRewardTabChange,
    onAddToDashboard,
    selectedReward // Prop for the selected reward object
}) {
    const [shouldRender, setShouldRender] = useState(totalPts > 0);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        let timeoutId;

        if (totalPts > 0) {
            setShouldRender(true);
            requestAnimationFrame(() => setMounted(true));
        } else if (shouldRender) {
            setMounted(false);
            timeoutId = setTimeout(() => setShouldRender(false), 500);
        }

        return () => clearTimeout(timeoutId);
    }, [totalPts, shouldRender]);

    if (!shouldRender) return null;

    const categories = rewardTabs.map(key => ({
        key,
        label: rewardLabels[key] || key
    }));

    // Find the currently selected reward object from availableRewards
    const currentSelectedReward = availableRewards.find(r => r.id === selectedRewardId);

    return (
        <div
            className={`fixed bottom-0 inset-x-0 bg-white
                rounded-t-[28px] overflow-hidden
                transform transition-transform duration-500 ease-out
                ${mounted ? 'translate-y-0' : 'translate-y-full'}
            `}
            style={{ boxShadow: '0 -20px 20px -10px rgba(0,0,0,0.2)' }}
        >
            {/* Est pts */}
            <div className="mb-2 pt-5 pb-3 px-6">
                <div className="flex justify-center items-baseline space-x-1">
                    <span className="text-sm">Est</span>
                    <img
                        src={PointsRooLogo}
                        alt="Points Roo logo"
                        className="w-4 h-4 pt-[3px] mr-0"
                    />
                    <span className="text-base font-bold">
                        {totalPts.toLocaleString()}
                    </span>
                    <span className="text-xs uppercase">PTS</span>
                    <span className="text-sm">/year from selected</span>
                </div>
            </div>

            {/* Reward display */}
            <div className="px-6 -mt-[5px]">
                <div className="text-right text-sm text-red-600 underline mb-2">
                    See more
                </div>
                {currentSelectedReward ? (
                    <div className="p-2 rounded text-left border-2 border-red-600">
                        <div className="font-medium text-sm mb-1">{currentSelectedReward.reward}</div>
                        <div className="text-xs">
                            {currentSelectedReward.costAUD
                                ? `Use ${currentSelectedReward.pts.toLocaleString()} PTS + $${currentSelectedReward.costAUD.toFixed(2)}`
                                : `${currentSelectedReward.pts.toLocaleString()} PTS`}
                        </div>
                    </div>
                ) : (
                    // Display the first available flight reward if none is selected yet
                    availableRewards.find(r => r.reward.includes('Sydney to')) ? (
                        <div className="p-2 rounded text-left border border-gray-300">
                            <div className="font-medium text-sm mb-1">{availableRewards.find(r => r.reward.includes('Sydney to')).reward}</div>
                            <div className="text-xs">
                                {availableRewards.find(r => r.reward.includes('Sydney to')).costAUD
                                    ? `Use ${availableRewards.find(r => r.reward.includes('Sydney to')).pts.toLocaleString()} PTS + $${availableRewards.find(r => r.reward.includes('Sydney to')).costAUD?.toFixed(2)}`
                                    : `${availableRewards.find(r => r.reward.includes('Sydney to')).pts.toLocaleString()} PTS`}
                            </div>
                        </div>
                    ) : null
                )}
            </div>

            {/* Add button */}
            <div className="p-5">
                <button
                    className="w-full br-4 py-3 bg-red-600 font-semibold tracking-widest text-white text-base rounded-sm"
                    onClick={onAddToDashboard}
                >
                    ADD TO DASHBOARD
                </button>
            </div>
        </div>
    );
}