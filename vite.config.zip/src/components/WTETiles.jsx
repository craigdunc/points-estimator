// src/components/WTETiles.jsx
import React from 'react'
import { WTEs } from '../data'

export default function WTETiles({
  selectedWTEs,
  setupProgressByWTE,
  monthlyEarnedByWTE,
  monthlyTargetByWTE,
  onSetupClick,
}) {
  return (
    <div className="grid grid-cols-3 gap-6 justify-items-center">
      {selectedWTEs.map(({ id }) => {
        const wte = WTEs.find(w => w.id === id)
        if (!wte) return null

        const setupSteps = setupProgressByWTE[id] || 0
        const earned     = monthlyEarnedByWTE[id] || 0
        const target     = monthlyTargetByWTE[id] || 1 // avoid /0
        const percent    = earned
          ? Math.min((earned / target) * 100, 100)
          : (setupSteps / 4) * 100

        /* ───────────────────── tile ───────────────────── */
        return (
          <div key={id} className="flex flex-col items-center">
            {/* WTE name (2-line clamp) */}
            <div
              className="text-xs font-medium mb-1 text-center overflow-hidden"
              style={{
                display: '-webkit-box',
                WebkitBoxOrient: 'vertical',
                WebkitLineClamp: 2,
                minHeight: '2rem',
              }}
            >
              {wte.name}
            </div>

            {/* progress ring w/ icon */}
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 36 36" className="w-full h-full">
                <circle
                  cx="18" cy="18" r="16"
                  stroke="#e5e7eb" strokeWidth="2" fill="none"
                />
                <circle
                  cx="18" cy="18" r="16"
                  stroke="#dc2626" strokeWidth="2" fill="none"
                  strokeDasharray={`${percent} 100`}
                  transform="rotate(90 18 18)"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <img
                  src={wte.iconSrc}
                  alt={`${wte.name} logo`}
                  className="w-11 h-11 object-contain"
                />
              </div>
            </div>

            {/* Earned number OR setup button */}
            {earned > 0 ? (
              <div className="flex items-end mt-2">
                <span className="font-bold text-lg leading-none">
                  {earned.toLocaleString()}
                </span>
                <span className="font-normal text-sm leading-none ml-1">
                  PTS
                </span>
              </div>
            ) : (
              <>
                <button
                  onClick={() => onSetupClick(id)}
                  className="mt-2 px-3 py-1 bg-white border rounded-full text-sm font-semibold"
                >
                  Set&nbsp;up
                </button>
                <div className="text-xs text-gray-500 mt-1">+50&nbsp;PTS</div>
              </>
            )}
          </div>
        )
      })}

      {/* “Add new” tile */}
      <div className="flex flex-col items-center">
        <button
          onClick={() => onSetupClick(null)}
          className="mt-[40px] w-16 h-16 flex items-center justify-center border rounded-full text-2xl"
        >
          +
        </button>
        <button
          onClick={() => onSetupClick(null)}
          className="mt-4 text-sm text-red-600"
        >
          Add
        </button>
      </div>
    </div>
  )
}
