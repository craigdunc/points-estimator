// src/components/MonthChange.jsx
import React, { useState, useEffect } from 'react'
import { useSaveSlots } from '../state/useSaveSlots'
import { WTEs } from '../data'

const monthNames = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
]

export default function MonthChange({ goBack }) {
  const { current, saveState } = useSaveSlots()

  /* ── pull slot data ───────────────────────────────────────── */
  const selectedIds = (current.selectedWTEs || []).map(x =>
    typeof x === 'object' ? x.id : x
  )
  const targetById  = current.monthlyTargetByWTE || {}
  const [y, m]      = (current.currentMonth || '0000-01').split('-').map(Number)
  /* ─────────────────────────────────────────────────────────── */

  /* local UI state */
  const [monthNum,      setMonthNum]      = useState(m || 1)
  const [earnedById,    setEarnedById]    = useState({})
  const [hasAdvanced,   setHasAdvanced]   = useState(false)

  /* helper: bump month & wrap to 1 after 12 */
  const nextMonthNum = monthNum === 12 ? 1 : monthNum + 1
  const nextIso      = `${y}-${String(nextMonthNum).padStart(2, '0')}`

  const advance = () => {
    /* 1️⃣ generate earned ±20 % around each WTE target */
    const results = {}
    let total     = 0
    selectedIds.forEach(id => {
      const tgt    = targetById[id] ?? 0
      const actual = Math.floor(tgt * (0.8 + Math.random() * 0.4))
      results[id]  = actual
      total       += actual
    })

    /* 2️⃣ persist back into this slot */
    saveState({
      ...current,
      currentMonth:       nextIso,
      monthlyEarnedByWTE: results,
      currentPtsBalance:  (current.currentPtsBalance || 0) + total
    })

    /* 3️⃣ update local UI */
    setMonthNum(nextMonthNum)
    setEarnedById(results)
    setHasAdvanced(true)
  }

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-xl font-bold">
        Month: {monthNames[monthNum - 1]}
      </h2>

      <ul className="space-y-2">
        {selectedIds.map(id => {
          const wte = WTEs.find(w => w.id === id) || { name: id }
          const tgt = targetById[id] ?? 0
          const earn = earnedById[id]

          return (
            <li key={id} className="flex justify-between">
              <span>{wte.name}</span>
              {hasAdvanced
                ? <span>Target {tgt} → Earned {earn} pts</span>
                : <span>{tgt} pts / month</span>}
            </li>
          )
        })}
      </ul>

      <button
        onClick={advance}
        className="w-full py-3 bg-blue-600 text-white font-semibold tracking-widest rounded-sm"
      >
        Advance Month
      </button>

      <button
        onClick={goBack}
        className="w-full py-3 bg-red-600 text-white font-semibold tracking-widest rounded-sm"
      >
        Dashboard
      </button>
    </div>
  )
}
