// src/components/MonthChange.jsx

import React, { useState, useEffect } from 'react'
import { loadDashboardState, saveDashboardState } from '../utils/dashboardStorage'
import { WTEs } from '../data'

const monthNames = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
]

export default function MonthChange({ goBack }) {
  // local UI
  const [monthName, setMonthName] = useState('')
  const [targets,   setTargets]   = useState({})
  const [earned,    setEarned]    = useState({})
  const [advanced,  setAdvanced]  = useState(false)

  // 1️⃣ On mount: load ISO month from storage and show it
  useEffect(() => {
    const ds = loadDashboardState()
    const iso = ds.currentMonth
    const mm  = iso.slice(5,7)
    setMonthName(monthNames[parseInt(mm,10)-1] || iso)
  }, [])

  // 2️⃣ When user clicks Advance Month…
  const advanceMonth = () => {
    const state = loadDashboardState()

    // bump the ISO month
    const [y, m]   = state.currentMonth.split('-').map(Number)
    const nextIso  = new Date(y, m, 1).toISOString().slice(0,7)
    state.currentMonth = nextIso

    // grab the monthly targets you seeded in WTESelection
    const tmap = state.monthlyTargetByWTE || {}

    // randomise each WTE’s earned ±20%
    const newEarned = {}
    let total = 0
    Object.entries(tmap).forEach(([id, tgt]) => {
      const actual = Math.floor(tgt * (0.8 + Math.random()*0.4))
      newEarned[id] = actual
      total       += actual
    })
    state.monthlyEarnedByWTE = newEarned
    state.currentPtsBalance += total

    // persist & debug‐log
    saveDashboardState(state)
    console.log('[MonthChange] after Advance:', state)

    // update UI
    const mm2 = nextIso.slice(5,7)
    setMonthName(monthNames[parseInt(mm2,10)-1] || nextIso)
    setTargets(tmap)
    setEarned(newEarned)
    setAdvanced(true)
  }

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-xl font-bold">Month: {monthName}</h2>

      {!advanced ? (
        <button
          onClick={advanceMonth}
          className="w-full py-3 bg-blue-600 text-white font-semibold tracking-widest rounded-sm"
        >
          Advance Month
        </button>
      ) : (
        <>
          <ul className="space-y-2">
            {Object.entries(targets).map(([id, tgt]) => {
              const w   = WTEs.find(w=>w.id===+id) || { name: id }
              const pts = earned[id] || 0
              return (
                <li key={id} className="flex justify-between">
                  <span>{w.name}</span>
                  <span>Target {tgt} pts → Earned {pts} pts</span>
                </li>
              )
            })}
          </ul>
          <button
            onClick={goBack}
            className="w-full py-3 bg-red-600 text-white font-semibold tracking-widest rounded-sm"
          >
            SEE DASHBOARD
          </button>
        </>
      )}
    </div>
  )
}
