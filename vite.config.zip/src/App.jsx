// src/App.jsx
import React, { useState } from 'react'
import SlotSelect    from './screens/SlotSelect'
import Intro1        from './screens/Intro1'
import Intro2        from './screens/Intro2'
import WTESelection  from './screens/WTESelection'
import Dashboard     from './screens/Dashboard'
import MonthChange   from './components/MonthChange'

const steps = [
  SlotSelect,
  Intro1,
  Intro2,
  WTESelection,
  Dashboard,
  MonthChange,   // run your month-advance logic here
]

export default function App() {
  const [stepIndex, setStepIndex] = useState(0)
  const Screen = steps[stepIndex]

  const goNext = () => {
    if (stepIndex < steps.length - 1) {
      setStepIndex(i => i + 1)
    }
  }

  const goBack = () => {
    if (stepIndex > 0) {
      setStepIndex(i => i - 1)
    }
  }

 // pass both handlers; screens that don’t use goBack will simply ignore it
  return <Screen goNext={goNext} goBack={goBack} />
}