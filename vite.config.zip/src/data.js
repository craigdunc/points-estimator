// import Everyday logo assets (put them into src/assets/logos/)
import RedEnergyLogo        from './assets/logos/red-energy.svg';
import WoolworthsLogo       from './assets/logos/everyday-rewards-woolworths.svg';
import NoFeeCardLogo        from './assets/logos/no-annual-fee-card.svg';
import BpRewardsLogo        from './assets/logos/bp-rewards.svg';
import QantasWellbeingLogo  from './assets/logos/qantas-wellbeing.svg';
import QantasPayLogo        from './assets/logos/qantas-pay.svg';
import BingeLogo            from './assets/logos/binge.svg';
// --- logo imports for Big Points Earners ---
import PointsCardLogo       from './assets/logos/points-earning-credit-card.svg';
import HomeLoanLogo         from './assets/logos/qantas-home-loan.svg';
import CarInsuranceLogo     from './assets/logos/qantas-car-insurance.svg';
import HomeInsuranceLogo    from './assets/logos/qantas-home-insurance.svg';
import WineLogo             from './assets/logos/qantas-wine.svg';
import HealthInsuranceLogo  from './assets/logos/qantas-health-insurance.svg';
// --- logo imports for Shop Earners ---
import EverydayShopLogo     from './assets/logos/everyday-rewards-shop.svg';
import MarketplaceLogo      from './assets/logos/qantas-marketplace.svg';
import OnlineMallLogo       from './assets/logos/shopping-online-mall.svg';
import DirectLinkLogo       from './assets/logos/direct-link-partners.svg';
// --- logo imports for Travel Earners ---
import FlightsLogo	    from './assets/logos/flights.svg';
import HotelsLogo           from './assets/logos/hotels.svg';
import ActivitiesLogo       from './assets/logos/activities.svg';
import CarsLogo             from './assets/logos/cars.svg';
import QantasPayTravelLogo  from './assets/logos/qantas-pay-travel.svg';
import AccorLogo            from './assets/logos/accor.svg';
import HolidaysLogo         from './assets/logos/holidays.svg';
import TADLogo              from './assets/logos/trip-a-deal.svg';
import CruisesLogo          from './assets/logos/cruises.svg';

// ─────────────────────────────────────────────
// Ways to Earn (WTE) – 30 entries, 5 tiers each
// ─────────────────────────────────────────────
export const WTEs = [
  // ─── EVERYDAY ───
  {
    id: 1,
    name: 'Red Energy',
    iconSrc: RedEnergyLogo,
    category: 'everyday',
    desc: 'Earn up to 15,000 bonus Qantas Points when you switch, then 2 points per A$1 on energy bills paid on time. Conditions apply.',
    tiers: [
      { spend: 5000,  pts: 7350  },
      { spend: 7500,  pts: 11000 },
      { spend: 10000, pts: 14700 },
      { spend: 15000, pts: 20000 },
      { spend: 20000, pts: 26000 },
    ],
  },
  {
    id: 2,
    name: 'Everyday Rewards',
    iconSrc: WoolworthsLogo,
    category: 'everyday',
    desc: 'Convert 2,000 Rewards points into 1,000 Qantas Points automatically at Woolworths, BIG W and BWS. Conditions apply.',
    tiers: [
      { spend: 1000, pts: 2000  },
      { spend: 2000, pts: 4000  },
      { spend: 3000, pts: 8600  },
      { spend: 5000, pts: 14000 },
      { spend: 8000, pts: 22000 },
    ],
  },
  {
    id: 3,
    name: 'No Annual Fee Credit Card',
    iconSrc: NoFeeCardLogo,
    category: 'everyday',
    desc: 'Earn up to 8,000 bonus Qantas Points with no annual fee and collect points on everyday spend. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 750  },
      { spend: 1000, pts: 1125 },
      { spend: 1500, pts: 1500 },
      { spend: 2000, pts: 1875 },
      { spend: 2500, pts: 2250 },
    ],
  },
  {
    id: 4,
    name: 'BP Rewards',
    iconSrc: BpRewardsLogo,
    category: 'everyday',
    desc: 'Swipe at bp to earn up to 2 points per litre on Ultimate 98 and 1 point per A$1 in-store. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 700  },
      { spend: 1000, pts: 1050 },
      { spend: 1500, pts: 1400 },
      { spend: 2000, pts: 1750 },
      { spend: 2500, pts: 2100 },
    ],
  },
  {
    id: 5,
    name: 'Qantas Wellbeing',
    iconSrc: QantasWellbeingLogo,
    category: 'everyday',
    desc: 'Earn up to 1,000 bonus points in 28 days, then daily points for steps, sleep and wellness challenges. Conditions apply.',
    tiers: [
      { spend: 300,  pts: 450  },
      { spend: 600,  pts: 675  },
      { spend: 900,  pts: 900  },
      { spend: 1200, pts: 1125 },
      { spend: 1500, pts: 1350 },
    ],
  },
  {
    id: 6,
    name: 'Qantas Pay',
    iconSrc: QantasPayLogo,
    category: 'everyday',
    desc: 'Earn 1.5 points per A$1 spent overseas and 1 point per A$4 in Australia with Qantas Pay. Conditions apply.',
    tiers: [
      { spend: 200,  pts: 250  },
      { spend: 400,  pts: 375  },
      { spend: 600,  pts: 500  },
      { spend: 800,  pts: 625  },
      { spend: 1000, pts: 750  },
    ],
  },
  {
    id: 7,
    name: 'Binge',
    iconSrc: BingeLogo,
    category: 'everyday',
    desc: 'Score 1,000 bonus points when you join Binge, plus 50 points every month you stay subscribed. Conditions apply.',
    tiers: [
      { spend: 100, pts: 150 },
      { spend: 200, pts: 225 },
      { spend: 300, pts: 300 },
      { spend: 400, pts: 375 },
      { spend: 500, pts: 450 },
    ],
  },
 // --- BIG POINTS EARNERS ---
  {
    id: 12,
    name: 'Points Earning Credit Card',
    iconSrc: PointsCardLogo,
    category: 'big',
    desc: 'Collect up to 120,000 bonus points on signup and earn up to 1.25 points per A$1 on eligible spend. Conditions apply.',
    tiers: [
      { spend: 1000, pts: 50000  },
      { spend: 2500, pts: 75000  },
      { spend: 4000, pts: 125000 },
      { spend: 12000, pts: 150000 },
      { spend: 20000, pts: 200000 },
    ],
  },
  {
    id: 13,
    name: 'Qantas Home Loan',
    iconSrc: HomeLoanLogo,
    category: 'big',
    desc: 'Receive 100,000–150,000 Qantas Points every year with an eligible Qantas Money Home Loan. Conditions apply.',
    tiers: [
      { spend: 10000, pts: 50000  },
      { spend: 25000, pts: 75000  },
      { spend: 40000, pts: 100000 },
      { spend: 65000, pts: 150000 },
      { spend: 80000, pts: 200000 },
    ],
  },
  {
    id: 14,
    name: 'Qantas Car Insurance',
    iconSrc: CarInsuranceLogo,
    category: 'big',
    desc: 'Earn up to 40,000 bonus points on a new car policy and 1 point per A$1 on premiums. Conditions apply.',
    tiers: [
      { spend: 200, pts: 6000  },
      { spend: 400, pts: 12000 },
      { spend: 800, pts: 24000 },
      { spend: 1600, pts: 36000 },
      { spend: 3000, pts: 48000 },
    ],
  },
  {
    id: 15,
    name: 'Qantas Home Insurance',
    iconSrc: HomeInsuranceLogo,
    category: 'big',
    desc: 'Earn up to 40,000 bonus points on home & contents cover and 1 point per A$1 on premiums. Conditions apply.',
    tiers: [
      { spend: 500, pts: 5000  },
      { spend: 750, pts: 10000 },
      { spend: 1000, pts: 20000 },
      { spend: 1200, pts: 30000 },
      { spend: 2500, pts: 40000 },
    ],
  },
  {
    id: 16,
    name: 'Qantas Wine',
    iconSrc: WineLogo,
    category: 'big',
    desc: 'Earn at least 1 point per A$1 and up to 10,000 bonus points on selected cases at Qantas Wine. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 3000  },
      { spend: 1000, pts: 6000  },
      { spend: 2000, pts: 12000 },
      { spend: 3000, pts: 18000 },
      { spend: 4000, pts: 24000 },
    ],
  },
  {
    id: 17,
    name: 'Qantas Health Insurance',
    iconSrc: HealthInsuranceLogo,
    category: 'big',
    desc: 'Join Qantas Health Insurance for up to 130,000 bonus points and 1 point per A$1 on premiums. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 3000  },
      { spend: 1000, pts: 6000  },
      { spend: 2000, pts: 12000 },
      { spend: 3000, pts: 18000 },
      { spend: 4000, pts: 24000 },
    ],
  },


  // --- SHOP entries below ---
  {
    id: 18,
    name: 'Everyday Rewards (Retail)',
    iconSrc: EverydayShopLogo,
    category: 'shop',
    desc: 'More than just groceries, earn at BIG W, PetStock and MyDeal. Every 2,000 Rewards points becomes 1,000 Qantas Points when you opt‑in. Conditions apply.',
    tiers: [
      { spend: 1000, pts: 2000 },
      { spend: 2000, pts: 4000 },
      { spend: 3000, pts: 8600 },
      { spend: 5000, pts: 14000 },
      { spend: 8000, pts: 22000 },
    ],
  },
  {
    id: 19,
    name: 'Qantas Marketplace',
    iconSrc: MarketplaceLogo,
    category: 'shop',
    desc: 'Shop 30,000+ products and earn up to 5 points per A$1 at Qantas Marketplace. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 1500 },
      { spend: 1000, pts: 2500 },
      { spend: 2000, pts: 3500 },
      { spend: 3000, pts: 4500 },
      { spend: 4000, pts: 5500 },
    ],
  },
  {
    id: 20,
    name: 'Shopping Online Mall',
    iconSrc: OnlineMallLogo,
    category: 'shop',
    desc: 'Start via Qantas Shopping and earn up to 10 points per A$1 at 450+ retailers. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 850  },
      { spend: 1000, pts: 1250 },
      { spend: 2000, pts: 1700 },
      { spend: 3000, pts: 2550 },
      { spend: 4000, pts: 3400 },
    ],
  },
  {
    id: 21,
    name: 'Direct Link Partners',
    iconSrc: DirectLinkLogo,
    category: 'shop',
    desc: 'Link partner accounts once and earn points automatically on qualifying transactions. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 850  },
      { spend: 1000, pts: 1250 },
      { spend: 2000, pts: 1700 },
      { spend: 3000, pts: 2550 },
      { spend: 4000, pts: 3400 },
    ],
  },
// --- TRAVEL entries below ---
  {
    id: 22,
    name: 'Qantas & Partner Flights',
    iconSrc: FlightsLogo,
    category: 'travel',
    desc: 'Earn points on every eligible flight with Qantas, Jetstar, over 30 oneworld® member and partner airlines.',
    tiers: [
      { spend: 300, pts: 1200 },
      { spend: 1000, pts: 4000 },
      { spend: 2500, pts: 10000 },
      { spend: 5000, pts: 20000 },
      { spend: 10000, pts: 40000 },
    ],
  },
  {
    id: 23,
    name: 'Qantas Hotels',
    iconSrc: HotelsLogo,
    category: 'travel',
    desc: 'Book hotels and accommodation via Qantas Hotels and earn 3 Qantas Points per A$1 spent on eligible stays. Conditions apply.',
    tiers: [
      { spend: 300,  pts: 900 },
      { spend: 800, pts: 2400 },
      { spend: 1500, pts: 4500 },
      { spend: 2500, pts: 7500 },
      { spend: 4000, pts: 12000 },
    ],
  },
  {
    id: 24,
    name: 'Qantas Activities',
    iconSrc: ActivitiesLogo,
    category: 'travel',
    desc: 'Earn 1 point per A$1 spent on tours, activities and expariences, powered by Viator. Conditions apply.',
    tiers: [
      { spend: 100,  pts: 100  },
      { spend: 300, pts: 300 },
      { spend: 600, pts: 600 },
      { spend: 1000, pts: 1000 },
      { spend: 2000, pts: 2000 },
    ],
  },
{
    id: 25,
    name: 'Qantas Cars',
    iconSrc: CarsLogo,
    category: 'travel',
    desc: 'Earn 4 Qantas Points per A$1 on the rate for Avis and Budget rentals, plus 700 points overseas. Conditions apply.',
    tiers: [
      { spend: 150,  pts: 600  },
      { spend: 400, pts: 1600 },
      { spend: 800, pts: 3200 },
      { spend: 1200, pts: 4800 },
      { spend: 2000, pts: 8000 },
    ],
  },

{
    id: 26,
    name: 'Qantas Pay (Travel Money)',
    iconSrc: QantasPayTravelLogo,
    category: 'travel',
    desc: 'Earn 1 Qantas Point per A$1 loaded with Qantas Pay, and 1 Point per A$1 spent overseas. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 750  },
      { spend: 2000, pts: 3000 },
      { spend: 5000, pts: 7500 },
      { spend: 8000, pts: 12000 },
      { spend: 12000, pts: 18000 },
    ],
  },

{
    id: 27,
    name: 'Accor Live Limitless',
    iconSrc: AccorLogo,
    category: 'travel',
    desc: 'Earn bonus Qantas Points on direct hotel spend. Earn both Qantas and ALL Reward points. Conditions apply.',
    tiers: [
      { spend: 250,  pts: 750  },
      { spend: 600, pts: 1800 },
      { spend: 1200, pts: 3600 },
      { spend: 2500, pts: 7500 },
      { spend: 4000, pts: 12000 },
    ],
  },
{
    id: 28,
    name: 'Qantas Holidays',
    iconSrc: HolidaysLogo,
    category: 'travel',
    desc: 'Earn 3 Qantas Points per A$1 spent on eligible holiday packages. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 1500 },
      { spend: 2000, pts: 6000 },
      { spend: 5000, pts: 15000 },
      { spend: 8000, pts: 24000 },
      { spend: 12000, pts: 36000 },
    ],
  },
{
    id: 29,
    name: 'Trip-A-Deal',
    iconSrc: TADLogo,
    category: 'travel',
    desc: 'Earn 3 Qantas Points per A$1 spent on eligible Trip-A-Deal holiday packages. Conditions apply.',
    tiers: [
      { spend: 500,  pts: 1500 },
      { spend: 2000, pts: 6000 },
      { spend: 5000, pts: 15000 },
      { spend: 8000, pts: 24000 },
      { spend: 12000, pts: 36000 },
    ],
  },

  {
    id: 30,
    name: 'Qantas Cruises',
    iconSrc: CruisesLogo,
    category: 'travel',
    desc: 'Earn 1 point per A$1 spent on your cruise. Qantas partners with the Award-winning Cruise Guru. Conditions apply.',
    tiers: [
      { spend: 1000,  pts: 1000 },
      { spend: 2000, pts: 2000 },
      { spend: 5000, pts: 5000 },
      { spend: 3000, pts: 3000 },
      { spend: 36000, pts: 36000 },
    ],
  },
];


// ─────────────────────────────────────────────
// Reward definitions (2 examples each)
// ─────────────────────────────────────────────
export const flightsList = [
  { id: 1, reward: 'Sydney to London', pts: 55200, costAUD: 326.89 },
  { id: 2, reward: 'Sydney to Tokyo', pts: 31500, costAUD: 166.89 },
  { id: 3, reward: 'Sydney to Seoul', pts: 26000, costAUD: 166.89 },
  { id: 4, reward: 'Sydney to Honolulu', pts: 26000, costAUD: 221.09 },
  { id: 5, reward: 'Sydney to Manila', pts: 25200, costAUD: 156.89 },
  { id: 6, reward: 'Sydney to Hong Kong', pts: 25200, costAUD: 156.89 },
  { id: 7, reward: 'Sydney to Bangkok', pts: 25200, costAUD: 159.29 },
  { id: 8, reward: 'Sydney to Singapore', pts: 25200, costAUD: 156.89 },
  { id: 9, reward: 'Sydney to Jakarta', pts: 20300, costAUD: 146.89 },
  { id: 10, reward: 'Sydney to Christchurch', pts: 18000, costAUD: 173.69 },
  { id: 11, reward: 'Sydney to Wellington', pts: 18000, costAUD: 190.09 },
  { id: 12, reward: 'Sydney to Nadi', pts: 14400, costAUD: 125.89 },
  { id: 13, reward: 'Sydney to Queenstown', pts: 14400, costAUD: 178.89 },
  { id: 14, reward: 'Sydney to Hobart', pts: 9600, costAUD: 38.68 },
  { id: 15, reward: 'Sydney to Canberra', pts: 8000, costAUD: 77.04 },
  { id: 16, reward: 'Sydney to Brisbane', pts: 6400, costAUD: 38.89 },
  { id: 17, reward: 'Sydney to Melbourne', pts: 6400, costAUD: 34.09 },
  { id: 99, reward: 'Points Plus Pay', pts: 5000, costAUD: 95.00 }
];

export const hotelsList = [
  { id: 1, reward: 'Ritz Carlton Melbourne', pts: 89987 },
  { id: 2, reward: 'Intercontinental Sorrento', pts: 69172 },
  { id: 3, reward: 'Parkroyal Melbourne Airport', pts: 54523 },
  { id: 4, reward: 'Lancemore Lindenderry Red Hill', pts: 44000 },
  { id: 5, reward: 'Quest East Melbourne', pts: 35804 },
  { id: 6, reward: 'Best Western Plus Travel Inn', pts: 26490 },
  { id: 7, reward: 'Lancemore rossley St. Melbourne', pts: 20000 },
  { id: 8, reward: 'Oaks Melbourne on Crossley', pts: 16000 }
];

export const activitiesList = [
  { id: 1, reward: 'Private Yarra Valley Getaway', pts: 473280 },
  { id: 2, reward: '12 Apostles Helicopter Tour', pts: 197940 },
  { id: 3, reward: 'Phillip Island Penguins Private Tour', pts: 146940 },
  { id: 4, reward: 'Private Grampian National Park Tours', pts: 99000 },
  { id: 5, reward: 'Helicopter Winery Lunch', pts: 77940 },
  { id: 6, reward: 'Classic Chevy Road Tour', pts: 60000 },
  { id: 7, reward: '2-Day Yarra Valley Wine Tour', pts: 39000 },
  { id: 8, reward: 'Melbourne Premium Balloon Tour', pts: 29880 }
];

export const marketplaceList = [
  { id: 1, reward: 'KitchenAid Artisan Stand Mixer', pts: 209800 },
  { id: 2, reward: 'Samsung 65‑inch 4K Smart TV', pts: 174500 },
  { id: 3, reward: 'Dyson Supersonic Hair Dryer', pts: 119800 },
  { id: 4, reward: 'oomba Combo Essential Robot', pts: 94800 },
  { id: 5, reward: 'Ultimate Ears Bluetooth Speaker ', pts: 69860 },
  { id: 6, reward: 'Tefal 5 Piece Cookware Set', pts: 59800 },
  { id: 7, reward: 'Bose QuietComfort Headphones', pts: 52700 },
  { id: 8, reward: 'Breville Essenza Coffee Machine', pts: 43800 },
  { id: 9, reward: 'Ninja Foodi Airfryer Max', pts: 39800 },
  { id: 10, reward: 'Samsonite 55cm Suitcase', pts: 32800 },
  { id: 11, reward: 'Royal Comfort Towel Set', pts: 21800 },
  { id: 12, reward: 'Wallabies Jersey - Womens', pts: 12960 },
  { id: 13, reward: 'Apple Airtag', pts: 9800 },
  { id: 14, reward: 'Qantas Luggage Tag', pts: 4000 },
  { id: 15, reward: 'Qantas Model Aeroplane', pts: 2400 }
];

export const giftCardsList = [
  { id: 1, reward: 'Myer Gift Card - $1000', pts: 207250 },
  { id: 2, reward: 'Digital Mastercard - $500', pts: 121850 },
  { id: 3, reward: 'Airbnb Gift Card - $500', pts: 105650 },
  { id: 4, reward: 'Amazon Gift Card - $250', pts: 54450 },
  { id: 5, reward: 'JB Hifi Gift Card - $250', pts: 51850 },
  { id: 6, reward: 'Green Card - $100', pts: 44610 },
  { id: 7, reward: 'Red Balloon Gift Voucher', pts: 20000 },
  { id: 8, reward: 'Bunnings Gift Card - $50', pts: 11690 },
  { id: 9, reward: 'Everyday Wish Gift Card - $25', pts: 5500 },
  { id: 10, reward: 'Hoyts Gift Card - $20', pts: 4400 }
];

export const entertainmentList = [
  { id: 1, reward: 'Keith Urban Tour VIP Ticket', pts: 150000 },
  { id: 2, reward: 'NRL Grand Final Premium Seat', pts: 133333 },
  { id: 3, reward: 'Melbourne Cup Package', pts: 116667 },
  { id: 4, reward: 'Back to the Future Musical Ticket', pts: 100000 },
  { id: 5, reward: 'Cirque du Soleil Premium Ticket', pts: 60000 },
  { id: 6, reward: 'MJ: The Musical Ticket', pts: 33333 },
  { id: 7, reward: 'Big Bash League T20 Ticket', pts: 10000 },
  { id: 8, reward: 'Royal Easter Show Entry', pts: 7500 },
  { id: 8, reward: 'A-League Soccer Match Ticket', pts: 4167 }
];