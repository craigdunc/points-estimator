// src/state/useSaveSlots.tsx
import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react'
import { v4 as uuid } from 'uuid'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface AppState {
  firstRunCompleted:       boolean
  selectedWTEs:            { id: string; level: string }[]
  totalAnnualPts:          number
  selectedWTU:             string | null
  selectedRewardId?:       string | null
  currentMonth:            string               // e.g. "October"
  monthlyEarnedByWTE:      Record<string, number>
  monthlyTargetByWTE:      Record<string, number>
  totalMonthlyPts:         number
  currentPtsBalance:       number
  setupProgressByWTE:      Record<string, number>
}

interface SaveSlot {
  id:      string  // uuid
  name:    string  // user label
  created: number  // timestamp
  state:   AppState
}

type Slots = SaveSlot[]

interface SlotsContextValue {
  slots:        Slots
  activeSlotId: string | null
  current:      AppState | null
  createSlot:   (name: string, initialState: AppState) => void
  renameSlot:   (id: string, newName: string) => void
  deleteSlot:   (id: string) => void
  loadSlot:     (id: string) => void
  saveState:    (patch: Partial<AppState>) => void
}

// ─── Context & Provider ──────────────────────────────────────────────────────

const STORAGE_KEY = 'qff_save_slots'
const SlotsCtx = createContext<SlotsContextValue | undefined>(undefined)

export function SaveSlotsProvider({ children }: { children: ReactNode }) {
  const [slots, setSlots]               = useState<Slots>([])
  const [activeSlotId, setActiveSlotId] = useState<string | null>(null)
  const [current, setCurrent]           = useState<AppState | null>(null)

  // Load from localStorage on first mount
  useEffect(() => {
    const json = localStorage.getItem(STORAGE_KEY)
    if (!json) return
    const saved: Slots = JSON.parse(json)
    setSlots(saved)
    if (saved.length) {
      setActiveSlotId(saved[0].id)
      setCurrent(saved[0].state)
    }
  }, [])

  // Persist whenever slots mutate
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(slots))
  }, [slots])

  // Create a new slot
  const createSlot = (name: string, initialState: AppState) => {
    const newSlot: SaveSlot = {
      id: uuid(),
      name,
      created: Date.now(),
      state: initialState,
    }
    setSlots(s => [newSlot, ...s])
    setActiveSlotId(newSlot.id)
    setCurrent(initialState)
  }

  // Rename an existing slot
  const renameSlot = (id: string, newName: string) => {
    setSlots(s =>
      s.map(slot => (slot.id === id ? { ...slot, name: newName } : slot))
    )
  }

  // Delete a slot (switch active if necessary)
  const deleteSlot = (id: string) => {
    setSlots(s => {
      const remaining = s.filter(slot => slot.id !== id)
      if (activeSlotId === id) {
        const next = remaining[0]
        setActiveSlotId(next?.id || null)
        setCurrent(next?.state || null)
      }
      return remaining
    })
  }

  // Load a slot into "current"
  const loadSlot = (id: string) => {
    const slot = slots.find(s => s.id === id)
    if (!slot) return
    setActiveSlotId(id)
    setCurrent(slot.state)
  }

  // Patch current state & persist to the active slot
  const saveState = (patch: Partial<AppState>) => {
    if (!activeSlotId) return
    setCurrent(prev => {
      const merged = prev ? { ...prev, ...patch } : (patch as AppState)
      setSlots(s =>
        s.map(slot =>
          slot.id === activeSlotId ? { ...slot, state: merged } : slot
        )
      )
      return merged
    })
  }

  return (
    <SlotsCtx.Provider
      value={{
        slots,
        activeSlotId,
        current,
        createSlot,
        renameSlot,
        deleteSlot,
        loadSlot,
        saveState,
      }}
    >
      {children}
    </SlotsCtx.Provider>
  )
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useSaveSlots() {
  const ctx = useContext(SlotsCtx)
  if (!ctx) throw new Error('useSaveSlots must be used within SaveSlotsProvider')
  return ctx
}
