import React from 'react'

export default function Intro1({ goNext }) {
  return (
    <div className="min-h-screen bg-white flex flex-col justify-between px-6 pt-42 pb-52">
      <div>
        <h1 className="text-3xl font-medium mb-6">
          Welcome to Qantas Frequent Flyer!
        </h1>
        <p className="mb-6 text-base text-gray-800">
          You’ve just joined a community of Australians who, like you, are finding more value in every journey.
        </p>
      </div>

      <button
        onClick={goNext}
        className="w-full py-3 bg-red-600 font-semibold tracking-widest text-white text-base rounded-sm"
      >
        NEXT
      </button>
    </div>
  )
}
