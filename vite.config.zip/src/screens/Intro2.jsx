//Intro 2

import React from 'react'

export default function Intro1({ goNext }) {
  return (
    <div className="min-h-screen bg-white flex flex-col justify-between px-6 pt-42 pb-52">
      <div>
        <h1 className="text-3xl font-medium mb-6">
         Let’s get you some points
        </h1>
        <p className="mb-6 text-base text-gray-800">
          One of the best ways to get the most out of your membership is by finding a few different ways of earning points.
        </p>
      </div>

      <button
        onClick={goNext}
        className="w-full py-3 bg-red-600 font-semibold tracking-widest text-white text-base rounded-sm"
      >
        SHOW ME
      </button>
    </div>
  )
}
