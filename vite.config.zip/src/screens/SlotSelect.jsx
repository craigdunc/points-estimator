// src/screens/SlotSelect.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useSaveSlots } from '../state/useSaveSlots';

/* static constants */
const PASSWORD    = 'getready321';
const UNLOCK_FLAG = 'qff_demo_unlocked';

export default function SlotSelect({ goNext }) {
  /* ── 1. hooks that must ALWAYS run ─────────────────────────── */
  const {
    slots,
    activeSlotId,
    createSlot,
    loadSlot,
    renameSlot,
    deleteSlot,
  } = useSaveSlots();            // <— first hook

  /* password gate hooks (always exist) */
  const [unlocked, setUnlocked] = useState(
    localStorage.getItem(UNLOCK_FLAG) === 'true'
  );                             // second hook
  const [pwInput, setPwInput]   = useState('');           // third hook
  const pwRef = useRef(null);                            // fourth hook

  /* slot-editing hooks (declare them even if locked) */
  const [draftName, setDraftName] = useState('');        // fifth hook
  const nameInputRef = useRef(null);                     // sixth hook

  /* ── 2. side-effects ───────────────────────────────────────── */
  /* focus for password input */
  useEffect(() => {
    if (!unlocked) pwRef.current?.focus();
  }, [unlocked]);                                        // 7th hook

  /* whenever slot or unlock changes, seed name field */
  useEffect(() => {
    if (!unlocked) return;
    const slot = slots.find(s => s.id === activeSlotId);
    setDraftName(slot?.name || '');
    nameInputRef.current?.focus();
  }, [unlocked, activeSlotId, slots]);                    // 8th hook

  /* ── 3. handlers ───────────────────────────────────────────── */
  const tryUnlock = () => {
    if (pwInput.trim() === PASSWORD) {
      localStorage.setItem(UNLOCK_FLAG, 'true');
      setUnlocked(true);
    } else {
      alert('Sorry, that password is incorrect.');
      setPwInput('');
      pwRef.current?.focus();
    }
  };

  const commitRename = id => {
    const name = draftName.trim();
    if (name) renameSlot(id, name);
  };

  /* ── 4. render password screen if locked ───────────────────── */
  if (!unlocked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-6">
        <div className="w-full max-w-sm bg-white p-6 rounded-xl shadow space-y-4">
          <h1 className="text-xl font-bold text-center">Enter&nbsp;Password</h1>

          <input
            ref={pwRef}
            type="password"
            value={pwInput}
            onChange={e => setPwInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && tryUnlock()}
            placeholder="********"
            className="w-full border px-3 py-2 rounded focus:outline-none focus:ring"
          />

          <button
            onClick={tryUnlock}
            className="w-full bg-red-600 text-white font-semibold py-2 rounded"
          >
            Unlock
          </button>
        </div>
      </div>
    );
  }

  /* ── 5. (unlocked) normal Slot-select UI ───────────────────── */
  return (
    <div className="p-6 w-full">
      <h1 className="text-2xl font-bold mb-4">Onboarding Prototype</h1>
      <p className="mb-6">Choose a slot and enter a first name</p>

      {slots.map((slot, idx) => (
        <div
          key={slot.id}
          className={`relative pl-3 mb-2 w-full rounded border overflow-hidden
            ${slot.id === activeSlotId
              ? 'border-red-600 bg-red-50'
              : 'border-gray-300 bg-white'}`}
        >
          {/* slot number pill */}
          <button
            onClick={() => loadSlot(slot.id)}
            className={`absolute inset-y-0 left-0 w-10 flex items-center justify-center
              ${slot.id === activeSlotId
                ? 'bg-red-600 text-white'
                : 'bg-gray-300 text-black'}`}
          >
            {idx + 1}
          </button>

          {/* editable name / label */}
          {slot.id === activeSlotId ? (
            <input
              ref={nameInputRef}
              value={draftName}
              onChange={e => setDraftName(e.target.value)}
              onBlur={() => commitRename(slot.id)}
              onKeyDown={e => e.key === 'Enter' && nameInputRef.current.blur()}
              className="block w-full pl-10 pr-4 py-2 bg-white focus:outline-none"
            />
          ) : (
            <div
              onClick={() => loadSlot(slot.id)}
              className="pl-10 pr-4 py-2 cursor-pointer"
            >
              {slot.name}
            </div>
          )}

          {/* advance arrow */}
          <button
            onClick={() => goNext(slot.id)}
            className="absolute inset-y-0 right-0 w-10 flex items-center justify-center text-red-600"
          >
            ▶
          </button>
        </div>
      ))}

      {/* actions row */}
      <div className="mt-4 flex">
        <button
          onClick={() =>
            createSlot(`Slot ${slots.length + 1}`, {
              firstRunCompleted: false,
              selectedWTEs: [],
              totalAnnualPts: 0,
              selectedWTU: null,
              selectedRewardId: null,
              setupProgressByWTE: {},
              monthlyTargetByWTE: {},
              monthlyEarnedByWTE: {},
              currentMonth: new Date().toISOString().slice(0, 7),
              currentPtsBalance: 0,
            })
          }
          className="text-red-600"
        >
          + New Slot
        </button>

        {activeSlotId && (
          <button
            onClick={() => deleteSlot(activeSlotId)}
            className="ml-4 text-red-600"
          >
            Delete
          </button>
        )}
      </div>
    </div>
  );
}
