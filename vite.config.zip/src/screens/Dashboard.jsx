import React, { useState } from 'react';
import { useSaveSlots } from '../state/useSaveSlots';
import {
  flightsList,
  hotelsList,
  activitiesList,
  marketplaceList,
  giftCardsList,
  entertainmentList,
} from '../data';
import OnboardingStepper   from '../components/OnboardingStepper';
import WTETiles            from '../components/WTETiles';
import MonthWrapUpModal    from '../components/MonthWrapUpModal';

export default function Dashboard({ goNext, goBack }) {
  const { slots, activeSlotId, current } = useSaveSlots();
  if (!activeSlotId || !current) return null;
  const slot = slots.find(s => s.id === activeSlotId);

  const {
    selectedWTEs = [],
    totalAnnualPts = 0,
    selectedWTU,
    selectedRewardId,
    setupProgressByWTE = {},
    currentMonth = new Date().toISOString().slice(0, 7),
    monthlyTargetByWTE = {},
    monthlyEarnedByWTE = {},
    currentPtsBalance = 0
  } = current;

  const [onboardingWteId, setOnboardingWteId] = useState(null);
  const [showWrapUp, setShowWrapUp] = useState(false);
  const [wrapUpData, setWrapUpData] = useState(null);

  const monthNames = [
    'January','February','March','April','May','June',
    'July','August','September','October','November','December',
  ];
  const [, mm] = currentMonth.split('-');
  const monthName = monthNames[parseInt(mm, 10) - 1] || currentMonth;

  const memberTier = 'Bronze';
  const memberNumber = '1234567890';
  const monthlyTarget = Math.round(totalAnnualPts / 12);

  const rewardsMap = {
    Flights: flightsList,
    Hotels: hotelsList,
    Activities: activitiesList,
    Marketplace: marketplaceList,
    'Gift Cards': giftCardsList,
    Entertainment: entertainmentList,
  };
  const selectedReward =
    (rewardsMap[selectedWTU] || []).find(r => r.id === selectedRewardId) || null;

  const handleTimePasses = () => {
    const totalEarned = Object.values(monthlyEarnedByWTE).reduce((a, b) => a + b, 0);
    const totalTarget = Object.values(monthlyTargetByWTE).reduce((a, b) => a + b, 0);

    const metAnyWTE = Object.entries(monthlyTargetByWTE)
      .some(([id, tgt]) => (monthlyEarnedByWTE[id] || 0) >= tgt);
    const metMonth = totalEarned >= totalTarget;
    const bonusEligible = metMonth || metAnyWTE;

    setWrapUpData({
      monthName,
      totalEarned,
      totalTarget,
      earnedById: monthlyEarnedByWTE,
      targetsById: monthlyTargetByWTE,
      bonusEligible,
    });
    setShowWrapUp(true);
  };

  const handleCloseModal = () => {
    setShowWrapUp(false);
    goNext();
  };

  return (
    <>
      {/* --------------- MAIN DASHBOARD -------------------------- */}
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">{slot.name}</h1>
            <div className="text-sm text-gray-700">{memberTier}</div>
            <div className="text-xs text-gray-500">{memberNumber}</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">
              {currentPtsBalance.toLocaleString()}&nbsp;PTS
            </div>
            <div className="text-sm text-gray-500">
              {currentPtsBalance === 0 ? "Let's get started!" : 'Nice work!'}
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="text-xl font-bold">{monthName}</div>
          <div className="mt-2 inline-block rounded-full border border-gray-300 px-6 py-2">
            Target&nbsp;{monthlyTarget.toLocaleString()}&nbsp;PTS
          </div>
        </div>

        <WTETiles
          selectedWTEs={selectedWTEs}
          setupProgressByWTE={setupProgressByWTE}
          monthlyEarnedByWTE={monthlyEarnedByWTE}
          monthlyTargetByWTE={monthlyTargetByWTE}
          onSetupClick={id => (id ? setOnboardingWteId(id) : goBack())}
        />

        <div className="flex items-center justify-between px-2">
          <div className="text-sm text-gray-700">
            Target Annual Earn:&nbsp;{totalAnnualPts.toLocaleString()}&nbsp;PTS
          </div>
          <button onClick={goBack} className="text-sm text-gray-700 underline">
            Edit
          </button>
        </div>

        {selectedReward && (
          <div className="mx-2 rounded border p-4">
            <div className="font-semibold">Classic Reward Flight</div>
            <div className="mt-2 flex items-center justify-between text-lg font-bold">
              <div>{selectedReward.reward}</div>
              <div>{selectedReward.pts.toLocaleString()}&nbsp;PTS</div>
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Learn more about Classic Flight Rewards and availability. Taxes,
              fees and charges apply.
            </div>
          </div>
        )}

        <div className="mt-6">
          <button
            onClick={handleTimePasses}
            className="w-full rounded-sm py-3 font-semibold tracking-widest text-gray"
          >
            Time&nbsp;passes…
          </button>
        </div>
      </div>

      {/* --------------- MODALS --------------------------- */}
      {showWrapUp && wrapUpData && (
        <MonthWrapUpModal data={wrapUpData} onClose={handleCloseModal} />
      )}

      {onboardingWteId !== null && (
        <OnboardingStepper
          wteId={onboardingWteId}
          onDone={() => setOnboardingWteId(null)}
        />
      )}
    </>
  );
}
