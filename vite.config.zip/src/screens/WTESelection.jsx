// src/screens/WTESelection.jsx

import React, { useState, useEffect, useRef } from 'react';
import { useSaveSlots } from '../state/useSaveSlots';
import {
  WTEs,
  flightsList,
  hotelsList,
  activitiesList,
  marketplaceList,
  giftCardsList,
  entertainmentList
} from '../data';
// CategoryTabs is not used directly here anymore for the footer.
import WTEList from '../components/WTEList';
import StickyFooter from '../components/StickyFooter';

const categories = [
  { key: 'everyday', label: 'Everyday Earners' },
  { key: 'big',        label: 'Big Points Earners' },
  { key: 'shop',       label: 'Shop and Earn' },
  { key: 'travel',     label: 'Travel and Earn' }
];

// rewardTabs is still needed for rewardsMap and potentially initial selectedWTU
const rewardTabs = [
  'Flights','Hotels','Activities',
  'Marketplace','Gift Cards','Entertainment'
];

const rewardsMap = {
  Flights:        flightsList,
  Hotels:         hotelsList,
  Activities:     activitiesList,
  Marketplace:    marketplaceList,
  'Gift Cards':   giftCardsList,
  Entertainment: entertainmentList
};

export default function WTESelection({ goNext }) {
  const { slots, activeSlotId, saveState } = useSaveSlots();
  const slot = slots.find(s => s.id === activeSlotId);
  if (!slot) return null;

  const saved = slot.state || {};

  const [activeCategory, setActiveCategory] = useState(categories[0].key); // For WTEList
  const [selectedIds, setSelectedIds]         = useState(saved.selectedWTEs?.map(w => w.id) || []);
  const [expandedId, setExpandedId]           = useState(null); // For WTEList

  // activeRewardTab determines which list of rewards to look into for selectedRewardId
  // It's also saved as selectedWTU (Ways To Use)
  const [activeRewardTab, setActiveRewardTab] = useState(saved.selectedWTU || rewardTabs[0]);
  const [selectedRewardId, setSelectedRewardId] = useState(saved.selectedRewardId || null);

  const [tierIndexById, setTierIndexById] = useState(() => {
    const defaults = WTEs.reduce((acc, w) => ({ ...acc, [w.id]: 2 }), {});
    (saved.selectedWTEs || []).forEach(({ id, level }) => {
      const idx = parseInt(level, 10);
      if (!isNaN(idx)) defaults[id] = idx;
    });
    return defaults;
  });

  const prevTotalRef = useRef(saved.totalAnnualPts || 0);
  const tabsRef = useRef(null); // This was for WTE CategoryTabs, ensure it's still used or remove

    useEffect(() => { // This useEffect was for scrolling WTE category tabs
    const c = tabsRef.current; // If WTEList also has category tabs, this is fine
    const btn = c?.querySelector(`[data-key="${activeCategory}"]`);
    if (btn && c) { // Check if c (tabsRef.current) is not null
      const cw = c.offsetWidth;
      const center = btn.offsetLeft + btn.offsetWidth / 2;
      c.scrollTo({ left: center - cw / 2, behavior: 'smooth' });
    }
  }, [activeCategory]);


  const getTier = w => w.tiers[tierIndexById[w.id]];
  const totalAnnualPts = selectedIds.reduce((sum, id) => {
    const w = WTEs.find(w => w.id === id);
    return sum + (w ? getTier(w).pts : 0);
  }, 0);

  // availableRewards still depends on activeRewardTab to know which list to filter
  const availableRewards = (rewardsMap[activeRewardTab] || []).filter(
    r => r.pts <= totalAnnualPts
  );

  // Find the currently selected reward object from the correct list (determined by activeRewardTab)
  const selectedReward = (rewardsMap[activeRewardTab] || []).find(r => r.id === selectedRewardId) || null;


  useEffect(() => {
    if (totalAnnualPts !== prevTotalRef.current) {
      // When points change, re-evaluate the selected reward.
      // Default to the first available reward in the *current activeRewardTab* if the old one is no longer valid
      // or if nothing was selected.
      let newSelectedRewardId = null;
      const currentCategoryRewards = rewardsMap[activeRewardTab] || [];
      const affordableInCurrentCategory = currentCategoryRewards.filter(r => r.pts <= totalAnnualPts);

      if (selectedRewardId) {
          const stillAffordable = affordableInCurrentCategory.find(r => r.id === selectedRewardId);
          if (stillAffordable) {
              newSelectedRewardId = selectedRewardId;
          }
      }

      if (!newSelectedRewardId && affordableInCurrentCategory.length > 0) {
          // If activeRewardTab is 'Flights', prefer 'Sydney to...' otherwise first affordable
          if (activeRewardTab === 'Flights') {
            const initialFlight = affordableInCurrentCategory.find(r => r.reward.includes('Sydney to')) || affordableInCurrentCategory[0];
            newSelectedRewardId = initialFlight?.id || null;
          } else {
            newSelectedRewardId = affordableInCurrentCategory[0]?.id || null;
          }
      }
      setSelectedRewardId(newSelectedRewardId);
      prevTotalRef.current = totalAnnualPts;
    }
  }, [totalAnnualPts, activeRewardTab]); // Added activeRewardTab dependency

  useEffect(() => {
    const fullState = {
      ...saved,
      firstRunCompleted: saved.firstRunCompleted ?? true,
      selectedWTEs: selectedIds.map(id => ({ id, level: `${tierIndexById[id]}` })),
      totalAnnualPts,
      selectedWTU: activeRewardTab, // This is the "Ways To Use" category
      selectedRewardId,
      setupProgressByWTE: saved.setupProgressByWTE || {},
      monthlyTargetByWTE: selectedIds.reduce((acc, id) => {
        const w = WTEs.find(wte => wte.id === id);
        acc[id] = Math.round((w ? getTier(w).pts : 0) / 12);
        return acc;
      }, {}),
      monthlyEarnedByWTE: selectedIds.reduce((acc, id) => {
        acc[id] = (saved.monthlyEarnedByWTE || {})[id] || 0;
        return acc;
      }, {}),
      currentMonth: saved.currentMonth || new Date().toISOString().slice(0,7),
      currentPtsBalance: saved.currentPtsBalance || 0
    };
    saveState(fullState);
  }, [
    selectedIds,
    tierIndexById,
    totalAnnualPts,
    activeRewardTab,
    selectedRewardId,
    saveState, // Added saveState
    saved,
    getTier // Added getTier
  ]);

  const toggleSelectWTE = id => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };
  const toggleExpandWTE = id => setExpandedId(prev => (prev === id ? null : id));

  const handleTierChange = (id, idx) => {
    setTierIndexById(prev => ({ ...prev, [id]: idx }));
    if (!selectedIds.includes(id)) toggleSelectWTE(id);
  };

  const handleAddToDashboard = () => goNext();

  // This function is needed if the "See more" link is to change activeRewardTab
  // For now, the "See more" link doesn't change tabs, it's for future navigation
  // const handleRewardTabChangeForFooter = (tab) => {
  //   setActiveRewardTab(tab);
  //   // Auto-select the first available reward in the new tab
  //   const newCategoryRewards = rewardsMap[tab] || [];
  //   const firstAffordableInNewCategory = newCategoryRewards.filter(r => r.pts <= totalAnnualPts)[0];
  //   setSelectedRewardId(firstAffordableInNewCategory?.id || null);
  // };


  return (
    <div className="max-w-md mx-auto pb-[280px]"> {/* Adjusted padding for potentially shorter footer */}
      <div className="intro-text mb-6 px-[30px] pt-[30px] text-base leading-[18px]">
        Select ways of earning Qantas Points to add to your dashboard.
      </div>

      {/* WTE Category Tabs and List */}
      {/* Assuming WTEList or another component handles the WTE category tabs if needed */}
      {/* If you had CategoryTabs for WTEs, it would be here: */}
      {/* <CategoryTabs categories={categories} activeCategory={activeCategory} onCategoryChange={setActiveCategory} ref={tabsRef} /> */}

      <WTEList
        WTEs={WTEs}
        activeCategory={activeCategory} // This activeCategory is for WTE types (everyday, big, etc.)
        selectedIds={selectedIds}
        expandedId={expandedId}
        tierIndexById={tierIndexById}
        onToggleSelect={toggleSelectWTE}
        onToggleExpand={toggleExpandWTE}
        onTierChange={handleTierChange}
      />

      {selectedIds.length > 0 && (
        <StickyFooter
          totalPts={totalAnnualPts}
          // rewardTabs prop removed
          // activeRewardTab prop removed
          availableRewards={availableRewards} // Still needed for context in StickyFooter if it were to derive selected item
          selectedRewardId={selectedRewardId}
          // onSelectReward prop removed (selection is now via selectedRewardId prop)
          // onRewardTabChange prop removed
          onAddToDashboard={handleAddToDashboard}
          selectedReward={selectedReward} // Pass the derived selectedReward object
        />
      )}
    </div>
  );
}